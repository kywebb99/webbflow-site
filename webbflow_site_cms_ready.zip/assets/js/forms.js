
document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('.nav__toggle')?.addEventListener('click',()=>{
    document.querySelector('.nav')?.classList.toggle('open');
  });
  const forms = document.querySelectorAll('form.netlify-form');
  forms.forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const data = new FormData(form);
      if (!data.get('form-name')) data.set('form-name', form.getAttribute('name') || 'request');
      try {
        await fetch('/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams(data).toString()
        });
      } catch (err) {}
      window.location.href = '/thank-you.html';
    });
  });
});
