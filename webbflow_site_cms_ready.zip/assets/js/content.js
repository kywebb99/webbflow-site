
async function fetchJSON(path){ try{ const r = await fetch(path, {cache:'no-store'}); if(!r.ok) return null; return await r.json(); }catch(e){ return null; } }
document.addEventListener('DOMContentLoaded', async () => {
  const hero = await fetchJSON('/content/hero.json');
  if(hero){
    const h1 = document.querySelector('[data-hero=headline]');
    const p = document.querySelector('[data-hero=subhead]');
    const cta = document.querySelector('[data-hero=cta]');
    if(h1) h1.textContent = hero.headline || h1.textContent;
    if(p) p.textContent = hero.subhead || p.textContent;
    if(cta && hero.cta_text) cta.textContent = hero.cta_text;
  }
  const svc = await fetchJSON('/content/services.json');
  const svcWrap = document.querySelector('#services-cards');
  if(svc && svcWrap){
    svcWrap.innerHTML = svc.map(item => `<article class="card"><h3>${item.title}</h3><p>${item.desc||''}</p></article>`).join('');
  }
  const revs = await fetchJSON('/content/reviews.json');
  const revWrap = document.querySelector('#reviews-list');
  if(revs && revWrap){
    revWrap.innerHTML = revs.map(t => `<blockquote class="shadow">“${t}”</blockquote>`).join('');
  }
  const about = await fetchJSON('/content/about.json');
  if(about){
    const at = document.querySelector('[data-about=title]');
    const ab = document.querySelector('[data-about=body]');
    if(at) at.textContent = about.title || at.textContent;
    if(ab) ab.textContent = about.body || ab.textContent;
  }
});
